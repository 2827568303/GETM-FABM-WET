.\GetEFDC.exe getefdc.inp
