@echo off
rem EFDC Explorer 8.4 - portable launcher (ASCII only, must stay CRLF)
rem 1 proxy  2 mirror app+vb6 to a short path  3 local demo license stub
rem 4 seed EEMS db  5 register VB6 controls  6 register .NET license wrapper
rem 7 seed demo login  8 start EFDC Explorer
setlocal
set "SELF=%~dp0"
set "DST=%LOCALAPPDATA%\EFDC84"
set "APP=%DST%\app"
set "VB6=%DST%\vb6"
set "PS32=%WINDIR%\SysWOW64\WindowsPowerShell\v1.0\powershell.exe"
if not exist "%PS32%" set "PS32=powershell.exe"
set "PY=%SELF%tools\python\python.exe"
if exist "%PY%" goto haspy
set "PY="
where python >nul 2>nul
if not errorlevel 1 set "PY=python"
:haspy

echo [1/8] proxy exception for loopback
"%PS32%" -NoProfile -ExecutionPolicy Bypass -File "%SELF%tools\fix_proxy.ps1" >nul 2>nul

echo [2/8] mirror app and vb6 to short path "%DST%"
robocopy "%SELF%app" "%APP%" /MIR /R:2 /W:1 /NJH /NJS /NFL /NDL >nul
robocopy "%SELF%vb6" "%VB6%" /MIR /R:2 /W:1 /NJH /NJS /NFL /NDL >nul
if not exist "%APP%\EFDC_Explorer8.4.exe" goto mirrorfail
rem note: do not pass "%SELF%" here - it ends with a backslash and would escape the quote
"%PS32%" -NoProfile -ExecutionPolicy Bypass -File "%SELF%tools\unblock_package.ps1" -AppDir "%APP%" -Vb6Dir "%VB6%"

echo [3/8] local demo license stub on 127.0.0.1:8080
"%PS32%" -NoProfile -ExecutionPolicy Bypass -File "%SELF%tools\start_stub.ps1"

echo [4/8] seed the EEMS database
if not exist "%PUBLIC%\DSI\EEMS8.4" mkdir "%PUBLIC%\DSI\EEMS8.4" >nul 2>nul
if not exist "%PUBLIC%\DSI\EEMS8.3" mkdir "%PUBLIC%\DSI\EEMS8.3" >nul 2>nul
if not exist "%PUBLIC%\DSI\EEMS8.4\eems.mdb" copy /y "%SELF%app\efdc.mdb" "%PUBLIC%\DSI\EEMS8.4\eems.mdb" >nul

echo [5/8] register VB6 ActiveX controls from "%VB6%"
"%PS32%" -NoProfile -ExecutionPolicy Bypass -File "%SELF%tools\register_controls.ps1" -Folder "%VB6%"

echo [6/8] register .NET license wrapper DSILIC0/DSILIC1
"%PS32%" -NoProfile -ExecutionPolicy Bypass -File "%SELF%tools\register_net.ps1" -AppDir "%APP%"
if not errorlevel 3 goto regdone

echo.
echo   .. per-user registration did not activate the component on this PC.
echo   .. retrying once with administrator rights (a UAC prompt will appear).
echo.
"%PS32%" -NoProfile -Command "Start-Process -FilePath '%PS32%' -ArgumentList '-NoProfile','-ExecutionPolicy','Bypass','-File','%SELF%tools\register_net.ps1','-AppDir','%APP%' -Verb RunAs -Wait"
"%PS32%" -NoProfile -ExecutionPolicy Bypass -File "%SELF%tools\register_net.ps1" -AppDir "%APP%"
if not errorlevel 3 goto regdone

echo.
echo  ===============================================================
echo   STOP: the licence component cannot be activated on this PC.
echo   EFDC Explorer would only show the "licenseWrapper" dialog,
echo   so the start is skipped on purpose.
echo.
echo   Diagnostic run follows - watch the lines starting with "1)" .. "6)"
echo  ===============================================================
"%PS32%" -NoProfile -ExecutionPolicy Bypass -File "%SELF%tools\check_license_env.ps1" -AppDir "%APP%"
echo.
echo   report saved: "%SELF%license_env.txt"
echo   send that file (or a photo of this window) to the maintainer.
pause
goto done
:regdone

echo [7/8] seed demo login (email + password + remember)
"%PS32%" -NoProfile -ExecutionPolicy Bypass -File "%SELF%tools\seed_env.ps1" -AppDir "%APP%"

echo [8/8] start EFDC Explorer 8.4
start "" /D "%APP%" "%APP%\EFDC_Explorer8.4.exe"
if defined PY "%PY%" -X utf8 "%SELF%tools\attach_signin.py" 45
goto afterrun

:afterrun
tasklist /FI "IMAGENAME eq EFDC_Explorer8.4.exe" 2>nul | find /I "EFDC_Explorer8.4.exe" >nul
if not errorlevel 1 goto done
echo.
echo  ---------------------------------------------------------------
echo   EFDC did not start. Copy this folder to a local drive (not a
echo   network share, not inside the zip) and run the launcher again.
echo  ---------------------------------------------------------------
pause

:mirrorfail
echo.
echo  Copying app\ or vb6\ failed (long path or read-only media).
echo  Copy the folder to e.g. D:\EFDC and run the launcher again.
echo.
pause
goto done

:done
endlocal
